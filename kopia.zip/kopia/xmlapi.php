<?php
class xmlapi {
    public function __construct() {
     echo(json_encode(array('Error'=>'Action not found')));   
    }
}
?>