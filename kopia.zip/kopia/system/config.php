<?php
 $config[0]['adress'] = 'http://www.gsmkody.test.koziolek.biz';                    
?>